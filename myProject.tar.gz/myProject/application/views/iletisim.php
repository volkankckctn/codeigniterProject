				<div class="col-sm-9 padding-right">
					<center><h2 class="title text-center">İletişim</h2></br></center>
					
					<p>
						<?=$veri[0]->contact?>
					</p>
				</div>
			</div>
		</div>
	</section>