<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Üye Paneli</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->

							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title" >
										<a data-toggle="" data-parent="#accordian" href="<?=base_url()?>uye">
											<center>Hesap Bilgileri<center>
										</a>
									</h4>
								</div>
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a href="<?=base_url()?>uye/profil_sayfa">

                                            <center>Avatar<center>
                                        </a>
                                    </h4>
                                </div>
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a  href="<?=base_url()?>uye/sifre_degistir_sayfa">
                                            <center>Şifre Değiştir<center>
                                        </a>
                                    </h4>
                                </div>
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a  href="<?=base_url()?>uye/sepetim">

                                            <center>Sepetim<center>
                                        </a>
                                    </h4>
                                </div>
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a  href="<?=base_url()?>uye/siparislerim">

                                            <center>Siparişlerim<center>
                                        </a>
                                    </h4>
                                </div>
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a href="<?=base_url()?>uye/yorum_sayfa">

                                            <center>Yorumlarım<center>
                                        </a>
                                    </h4>
                                </div>
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a href="<?=base_url()?>uye/favori_sayfa">

                                            <center>Favori Ürünlerim<center>
                                        </a>
                                    </h4>
                                </div>
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a href="<?=base_url()?>uye/mesaj_sayfa">

                                            <center>Mesajlarım<center>
                                        </a>
                                    </h4>
                                </div>


							</div>

						</div><!--/category-products-->

					</div>
				</div>