

<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <center><h1 class="text-info">Admin Sayfasına Hoşgeldiniz.</h1></center>
                <center><h3 class="alert-info">Sol Taraftaki Menüden istediğiniz işlemi yapabilirisiniz <i class="fa fa-smile-o"></i></h3></center>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>